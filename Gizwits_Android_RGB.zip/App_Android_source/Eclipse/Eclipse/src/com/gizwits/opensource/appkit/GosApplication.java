package com.gizwits.opensource.appkit;

import android.app.Application;
public class GosApplication extends Application {

    public static int flag = 0;

    public void onCreate() {
        super.onCreate();
    }


}
